import React, { Component } from "react";

class Header extends Component {
    render() {
        return (
            <div className='container-fluid'>
                <div className='row align-items-center bg-primary'>
                    <img src="./images/walmartLogo.png" className='col-4' alt="Walmart logo" />
                    <h1 className='col-8  text-warning text-center '>Walmart Shopping</h1>
                </div>
            </div>

        )
    }
}

export default Header;