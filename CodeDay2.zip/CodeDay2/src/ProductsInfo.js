//class component

import React from "react";
import AddToCart from "./AddToCart";

class ProductInfo extends React.Component {
    counter=0;
    constructor()
    {
        super();
        // initialise the instance variables of the class
        // add the class scope to the function detailsEventHandler
        //this in a constructor -- current obj
        this.detailsEventHandler=this.detailsEventHandler.bind(this);
        this.state={
            showAddToCart:false
        }
        
    }
    addToCartEventHandler=()=>{
        // eventhandler -- best practice -- fat arrow function
        alert("Inside add to cart event handler"+this.counter);//0
        //this.showAddToCart=true;
        this.setState({showAddToCart:true});// merge with existing state and call the render again
       // alert("Show add to cart"+ this .showAddToCart);

    }
    detailsEventHandler=function(){
        alert("Inside details event handler"+this.counter);//error; this is undefined
    }
    render() {
        
        var productsArr = [
            { productId: "P101", name: "Samsung Galaxy Book", price: 156789, quantity: 23, description: "Samsung Galaxy Book", imgUrl: "./images/samsunggalaxyBook.jpg" },
            { productId: "P102", name: "Apple mac book", price: 256789, quantity: 2, description: "Apple mac book", imgUrl: "./images/macBook.jpg" },
            { productId: "P103", name: "Lenovo Pad", price: 67789, quantity: 3, description: "Lenovo Pad", imgUrl: "./images/lenovoIdeaPad.jpg" },
            { productId: "P104", name: "Dell Latitude", price: 123455, quantity: 10, description: "Dell Latitude", imgUrl: "./images/dellLatitude.jpg" },
            
        ];
        var cardArr = productsArr.map(item => {
            return (
                <div key={item.productId} className="col-3  card bg-primary text-warning">
                    <img src={item.imgUrl} alt={item.name} className="card-img-top img-responsive" />
                    <div className="card-body">
                        <h1 className="card-title">{item.name}</h1>
                        <p className="card-text">Price : Rs. {item.price}</p>
                        <p className="card-text">Quantity : {item.quantity}</p>
                        <input 
                        type="button" 
                        value="Add to cart" 
                        className="btn btn-warning"
                        onClick={this.addToCartEventHandler} />

                        <input 
                        type="button" 
                        value="Details" 
                        className="btn btn-warning m-2"
                        onClick={this.detailsEventHandler} />
                    </div>
                </div>
            )
        })
        // return the virtual DOM
        return (
            <div>
                <h1>Product Info Component</h1>
                <div className="container-fluid">
                    <div className="row ">

                      {cardArr}
                    </div>
                </div>
                {this.state.showAddToCart&&<AddToCart></AddToCart>}
            </div>
        );
    }
}

export default ProductInfo;

