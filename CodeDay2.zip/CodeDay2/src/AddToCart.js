import React, { Component } from 'react'

export default class AddToCart extends Component {
  render() {
    return (
      <div>
        <h1>AddToCart</h1></div>
    )
  }
}
