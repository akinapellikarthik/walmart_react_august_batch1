import React from 'react'

function Fashion() {
  return (
    <div>Fashion</div>
  )
}

export default Fashion