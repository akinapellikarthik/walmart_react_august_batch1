import React,{useState} from 'react';


function Groceries(props) {
    const selectEventHandler=(selectedItem)=>{
        props.onSelection(selectedItem);
    }
    var [items,setItems]=useState([
        {id:1,productName:"Coke"},
        {id:2,productName:"Sprite"},
        {id:3,productName:"Fanta"}
    ])
    var liArr=items.map(item=>{
        return(
            <li key={item.id}>
                {item.id }--- {item.productName}
                <input type="button" value="Select"
                className='btn btn-primary'
                onClick={()=>{
                    selectEventHandler(item);
                }}
                />
            </li>
        )
    })
  return (
    <div>
        <h1>Groceries component</h1>
        <ul>
            {liArr}
        </ul>
    </div>
  )
}

export default Groceries