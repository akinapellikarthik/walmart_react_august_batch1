//class component

import React from "react";
import AddToCart from "./AddToCart";
import Clock from "./Clock";

class ProductInfo extends React.Component {
    counter=0;
    constructor()
    {
        super();
        // initialise the instance variables of the class
        // add the class scope to the function detailsEventHandler
        //this in a constructor -- current obj
        this.detailsEventHandler=this.detailsEventHandler.bind(this);
        this.state={
            showAddToCart:false,
            selectedProduct:{},
            productsArr:[
                { productId: "P101", name: "Samsung Galaxy Book", price: 156789, quantity: 23, description: "Samsung Galaxy Book", imgUrl: "./images/samsunggalaxyBook.jpg" },
                { productId: "P102", name: "Apple mac book", price: 256789, quantity: 2, description: "Apple mac book", imgUrl: "./images/macBook.jpg" },
                { productId: "P103", name: "Lenovo Pad", price: 67789, quantity: 3, description: "Lenovo Pad", imgUrl: "./images/lenovoIdeaPad.jpg" },
                { productId: "P104", name: "Dell Latitude", price: 123455, quantity: 10, description: "Dell Latitude", imgUrl: "./images/dellLatitude.jpg" },
                
            ]
        }
        
    }
    addToCartEventHandler=(selectedProduct,event)=>{
        // eventhandler -- best practice -- fat arrow function
        alert("Inside add to cart event handler"+selectedProduct.productId);//0
        //this.showAddToCart=true;
        this.setState({showAddToCart:true,selectedProduct:selectedProduct},()=>{
            console.log("Show add to cart"+ this.state.showAddToCart);//true
            // saving the changes in the server; display some messages on the new view
            
        });// merge with existing state and call the render again
        //alert("Show add to cart"+ this.state.showAddToCart);//false
        console.log("Event details",event);
        

    }
    detailsEventHandler=function(selectedProduct){
        //alert("Inside details event handler"+this.counter);//error; this is undefined
        alert("Inside details event handler"+selectedProduct.productId);
    }

    onConfirmationEventHandler=(cartObj)=>{
        alert("Inside on confirmation in Product Info");
        console.log("Cart Obj in ProductInfo",cartObj);
        this.setState({showAddToCart:false});
        // reduce the quantity
        var pos=this.state.productsArr.findIndex(item=> cartObj.productId === item.productId);
        var tempArr=[...this.state.productsArr];
        tempArr[pos].quantity-=cartObj.quantitySelected;
        this.setState({productsArr:tempArr});
        this.props.onCartObjConfirmation(cartObj);
    }

    onCancelConfirmationEventHandler=()=>{
        this.setState({showAddToCart:false});
    }
    render() {
        
        var productsArr =this.state.productsArr ;
        var cardArr = productsArr.map(item => {
            return (
                <div key={item.productId} className="col-3  card bg-primary text-warning">
                    <img src={item.imgUrl} alt={item.name} className="card-img-top img-responsive" />
                    <div className="card-body">
                        <h1 className="card-title">{item.name}</h1>
                        <p className="card-text">Price : Rs. {item.price}</p>
                        <p className="card-text">Quantity : {item.quantity}</p>
                        <input 
                        type="button" 
                        value="Add to cart" 
                        className="btn btn-warning"
                        onClick={this.addToCartEventHandler.bind(this,item)} />

                        <input 
                        type="button" 
                        value="Details" 
                        className="btn btn-warning m-2"
                        onClick={()=>{
                            this.detailsEventHandler(item);
                        }} />
                    </div>
                </div>
            )
        })
        // return the virtual DOM
        return (
            <div>
                <h1>Product Info Component</h1>
                <Clock></Clock>
                <div className="container-fluid">
                    <div className="row ">

                      {cardArr}
                    </div>
                </div>
                {
                this.state.showAddToCart 
                &&
                    <AddToCart 
                        companyName="Walmart" 
                        selectedItem={this.state.selectedProduct}
                        onConfirmation={this.onConfirmationEventHandler}
                        onCancelConfirmation={this.onCancelConfirmationEventHandler}
                    >
                    </AddToCart>
                }
            </div>
        );
    }
}

export default ProductInfo;

/*
state
-- local mutable of the component
-- object ; initialise the object in the constructor
-- modify the state -- setState()


setState()
-- async function
-- modify the state and call the render method implicitly
-- batched together and executed 
-- 2 param
-- obj/function
    obj-- merged with the existing state;
    function -- return an object; rerurned object will be merged with the state
        -- whenever we modify the state based on its previous value
-- callback function; optional
    function which is called implicitly when the setState functions excution is complete
    operations which should be performed only after the completion of setState
update emp set salary =1000 where empId=101;// salary will be changed to 1000

update emp set salary =salary + 1000 where empId=102;// salary will be incremented by 1000


function myFunc()
{
    console.log("HI");
    setInterval(()=>{
        console.log("Inside the function");
    },3000);
    console.log("bye");
}

myFunc();// HI bye (after 3 sec )Inside the function

setInterval() -- async function

Inside render of Add To cart
Inside the callback

this.setState({ctr:0})
this.setState({ctr:ctr+1})
this.setState({ctr:ctr+1})
this.setState({ctr:ctr+1})
this.setState({ctr:ctr+1})
this.setState({ctr:ctr+1})

// this.state.ctr =5; // expected output
// this.state.ctr= ; output is unpredictable
setState -- async and batched together
this.setState({ctr:0})
this.setState((prevState)=>{
    return ({ctr:prevState.ctr +1})
})
this.setState((prevState)=>{
    return ({ctr:prevState.ctr +1})
})
this.setState((prevState)=>{
    return ({ctr:prevState.ctr +1})
})
this.setState((prevState)=>{
    return ({ctr:prevState.ctr +1})
})
this.setState((prevState)=>{
    return ({ctr:prevState.ctr +1})
})
// this.state.ctr =5; expected and real output






*/