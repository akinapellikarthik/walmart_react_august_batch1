import React from 'react'
import {Outlet,Link,Route,Routes} from "react-router-dom"

function Fresh(props) {

    
  return (
    <div>
        
        <ul>
            <li>
                <Link to="/fresh/groceries">Groceries</Link>
            </li>
            <li>
                <Link to="/fresh/fashion" >Fashion</Link>
            </li>
            <li>
                <Link to="/fresh/household" >Household</Link>
            </li>
        </ul>
        <br/>
        <h1> Fresh Products</h1>
        <Outlet></Outlet>
        <h2>Selected Item :{JSON.stringify(props.selectedItem)}</h2>
        <h2>_______________</h2>
    </div>
  )
}

export default Fresh