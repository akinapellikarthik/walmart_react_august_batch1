import React from 'react'
import {Link} from "react-router-dom";
import "./Menu.css"

function Menu() {
  return (
    <div className='container-fluid bg-warning text-primary'>
        <ul>
            <li>
                <Link to="/products">Products</Link>
            </li>
            <li>
                <Link to="/users">Users</Link>
            </li>
            <li>
                <Link to="/contactus" >Contact Us</Link>
            </li>
            <li>
                <Link to="/fresh">Fresh Products</Link>
            </li>
        </ul>

    </div>
  )
}

export default Menu