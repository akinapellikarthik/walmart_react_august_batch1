import React from 'react'

function HouseHold() {
  return (
    <div>HouseHold</div>
  )
}

export default HouseHold