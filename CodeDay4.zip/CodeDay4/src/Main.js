import React,{useState} from 'react';
import {Routes,Route} from "react-router-dom";
import Home from "./Home";
import Users from "./Users";
import ContactUs from './ContactUs';
import Page404 from './Page404';
import Details from './Details';
import Fresh from './Fresh';
import Groceries from './Groceries';
import Fashion from './Fashion';
import HouseHold from './HouseHold';


function Main() {
  const [selectedItem,setSelectedItem]=useState({})
  const onSelectionEventHandler=(selectedItem)=>{
    setSelectedItem(selectedItem);
  }
  return (
    <div>
      <Routes>
        <Route path="/fresh" element={<Fresh selectedItem={selectedItem}></Fresh>}>
        <Route path="/fresh/groceries" element ={<Groceries onSelection={onSelectionEventHandler}></Groceries>}></Route>
          <Route path="/fresh/fashion" element={<Fashion></Fashion>}></Route>
          <Route path="/fresh/household" element={<HouseHold></HouseHold>}></Route>
        
        </Route>
        <Route path="/details" element={<Details></Details>}>
          <Route path=":userId" element={<Details></Details>}></Route>
        </Route>
        <Route path="/products" element={<Home></Home>}></Route>
        <Route path="/users" element={<Users></Users>}></Route>
        <Route path="/contactus" element={<ContactUs></ContactUs>}></Route>
        <Route path="*" element={<Page404></Page404>}></Route>
      </Routes>
    </div>
  )
}

export default Main