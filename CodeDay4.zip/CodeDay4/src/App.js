import './App.css';
import Header from './Header';
import Footer from './Footer';
import {BrowserRouter} from "react-router-dom";
import Main from './Main';
import Menu from './Menu';
// functional component will always return Virtual DOM
// static component; only for display purpose (before version 17.x )
// hooks -- dynamic component 
function App() {
  return (
    <div>
      <Header></Header>
      <BrowserRouter>
        <Menu></Menu>
        <Main></Main>
      </BrowserRouter>
      <Footer></Footer>
    </div>
  );
}

export default App;
// image file is in src folder-- <img src={img1} alt="Logo of react" />
//<img src="../src/logo.svg" alt="Logo of react"/> -- error ;; browser cant access src
//<img src={img2} alt="React img"/> -- not work; from src folder cant access the public folder

// public folder -- relative path
// src folder -- import the image and give the image var using interpolation

//Best practice -- image
//static resource -- public 
// code -- src -- careful -- image is also going to be bundled and given as part of bundle .js file
// very big image -- bundle size -- increase --> take more time for initial load 


// Project -- minimise the bundle size -- initial load -- minimum time
// js -- uglification and minification -- remove white spaces; short names for var names

// logo of a company -- public 
// images(link) from database -- public 

// image file should be physically  in src folder before the bundling

/*
products -- images ; 1000's of products-- dynamic
images -- database -- dynamic
src -- rebuild the bundle file
src -- images which are permanent to the project
src -- avoid
src -- source code 
*/

/*
Bootstrap -- class names
classnames -- predefined
primary -- blue
danger -- red
warning -- yellow
success -- green

12column  grid layout

walmart -- 8 columns; image --4 columns

*/