import React, { Component } from 'react'

export default class Cart extends Component {
  render() {
    var trArr=this.props.cartArr.map(item=>{
        return(
            <tr key={item.productId}>
                <td>{item.name}</td>
                <td>{item.price}</td>
                <td>{item.quantitySelected}</td>
            </tr>
        )
    })
    return (
      <div>
        <h1>Cart</h1>
        <table className='table'>
            <thead>
                <tr>
                    <th>
                        Product Name
                    </th>
                    <th>
                        Price
                    </th>
                    <th>
                        Quantity Selected
                    </th>
                </tr>
            </thead>
            <tbody>
                {trArr}
            </tbody>
        </table>
        </div>
    )
  }
}
