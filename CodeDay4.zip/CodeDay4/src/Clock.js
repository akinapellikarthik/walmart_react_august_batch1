import React, { Component } from 'react'

export default class Clock extends Component {
    constructor()
    {
        super();
        this.state={
            timer:new Date(),
            clearIntervalId:0};
    }
    componentDidMount()
    {
        var clearIntervalId=setInterval(()=>{
            this.setState({timer:new Date()});
        },1000)
        this.setState({clearIntervalId:clearIntervalId})
        // fetch the data from the server for the initial load 
    }
    componentWillUnmount()
    {
        clearInterval(this.state.clearIntervalId);
        alert("Clock stopped");
    }
  render() {
    return (
      <div>Clock
        <h1> Current Time:{this.state.timer.toLocaleString()} </h1>
      </div>
    )
  }
}
