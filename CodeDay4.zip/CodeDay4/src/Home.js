import React, { Component } from 'react'
import ProductInfo from './ProductsInfo'
import Cart from "./Cart"

export default class Home extends Component {
    constructor() {
        super();
        this.state = { showProducts: true,cartArr:[] }
    }

    onCartObjConfirmationEventHandler=(cartObj)=>{
        console.log("Cart Obj In Home component",cartObj);
        /*
        var tempArr=[...this.state.cartArr,cartObj];
        this.setState({cartArr:tempArr});
        */
        this.setState((prevState)=>{
            return ({cartArr:[...prevState.cartArr,cartObj]})
        })
    }

    render() {
        return (
            <div className='container-fluid'>
                <div className='row'>
                    <div className='col-2 offset-10'>
                        {this.state.showProducts
                            ? <input type="button" value="Cart" className='btn btn-warning'
                                onClick={() => {
                                    this.setState({ showProducts: false })
                                }} />
                            : <input type="button" value="Products" className='btn btn-warning'
                                onClick={() => {
                                    this.setState({ showProducts: true })
                                }}
                            />}

                    </div>
                </div>
                <div className='row'>
                    <div className='col-12'>
                        {this.state.showProducts ?
                         <ProductInfo
                            onCartObjConfirmation={this.onCartObjConfirmationEventHandler}
                         >

                         </ProductInfo> : 
                         <Cart cartArr={this.state.cartArr}></Cart>}
                    </div>

                </div>



            </div>
        )
    }
}
