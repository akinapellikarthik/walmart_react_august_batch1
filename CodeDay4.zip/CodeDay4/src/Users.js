import React,{useState,useEffect} from 'react';
import  axios from "axios"
import Custome from './Custome';

function Users()
{
    //alert("Hello team");
    const changeCompanyNameEventHandler=()=>{
        setCompanyName("Spring People");// modify the companyName and rerender(rerender the entire function)
    }
    const modifyQuantityEventHandler=(str1)=>{
        if(str1 ==="dec")
        {
            setCtr((prevCtr)=>{
                return (prevCtr-1)
            })
        }
        else
        {
            setCtr((prevCtr)=>{
                return (prevCtr+1)
            })
        }
        
    }
    var [companyName,setCompanyName]=useState("Walmart");
    //useState will return an array
    // the 0th element will be the state var
    // the 1st element will be a function to modify the state var
    // setCompanyName --> setState() --> rerender the component
    // useState -- hook -- predefined functionality
    // designed -- 1 st time -- initialisation
    // 2nd time -- hold the state across renders

    // can have multiple state variable
    
    var [ctr,setCtr]=useState(0);
    var [users,setUsers]=useState([]);
    var [myTime,setMyTime]=useState(new Date());
    var [loading,setLoading]=useState(true);
    useEffect(()=>{
        console.log("UseEffect called with an empty dependency called");

    },[]);

    useEffect(()=>{
        console.log("UseEffect 2 called with an empty dependency called ");
    },[]);

    useEffect(()=>{
        console.log("UseEffect called with no second param ");
    });
    useEffect(()=>{
        console.log("use Effect with company name changed")
    },[companyName])

    useEffect(()=>{
        //componentDidMount
        var clearIntervalId=setInterval(()=>{
            setMyTime(new Date());
        },1000)
        return (()=>{
            // componentWillUnmount
            // called implicitly whenever the component is unmounted
            alert("Timer in users stopped");
            clearInterval(clearIntervalId);
        })
    }
    ,[])

    useEffect(()=>{
        // componentDidMount
        // talk with api
        var serverUrl="https://jsonplaceholder.typicode.com/users";
        axios.get(serverUrl)
        .then((response)=>{
            console.log("Response from the server",response);
            setUsers(response.data);
            setLoading(false);

        })
        .catch((err)=>{
            console.log("Error for the get request",err)
        })
    },[])

    var trArr=users.map(item=>{
        return (
            <React.Fragment key={item.id}>
                <Custome item={item} ></Custome>
            </React.Fragment>
            
            
        )
    })

    return(
        <div>
            <h1>Users Component</h1>
            <h2>Company Name : {companyName}</h2>
            <input type="button" value="Change company name" 
            onClick={changeCompanyNameEventHandler}
            />
            <h2>Time: {myTime.toLocaleString()}</h2>
            <br/>
            <input type="button" value="-" className='btn btn-success m-2'
                onClick={()=>{
                    modifyQuantityEventHandler("dec")
                  }}
                />
            <span>{ctr}</span>
            <input type="button" value="+" className='btn btn-success m-2'
               onClick={()=>{
                modifyQuantityEventHandler("inc")
              }}
                
                />
            <br/>
            {
            loading ? <h1>Loading ....</h1>:
            <table className='table'>
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>EmailId</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {trArr}
                </tbody>
            </table>
            } 
        </div>
    );
}

export default Users;
/*
desctructuring an array -- based on the position
var arr1=[10,20,30,40,50];
var first = arr1[0];
var second=arr1[1];
var [first,second]=arr1;
clg(first);//10
clg(second);//20

var [second,first]=arr1;
clg(first);//20
clg(second);//10

var [first,,third]=arr1;
clg(first);//10
clg(third);//30

var obj={empId:101,empName:"sara",salary:5678};
// obj based on field names
var {salary}=obj;
clg(salary);//5678


useEffect(function,optional dependency list)
1. useEffect(function,[]);
work like componentDidMount
-- called only once after the component is mounted

2. useEffect(function)
-- work like componentDidUpdate and called in the initial load

3. useEffect(fucntion,[companyName])
-- work like componentDidUpdate
-- componentShouldUpdate -- boolean value
if companyname changes -- useEffect will be called
if company name does not change -- useEffect will not be called
*/