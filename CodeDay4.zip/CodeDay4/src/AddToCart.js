import React, { Component } from 'react'

export default class AddToCart extends Component {
  constructor(props)
  {
    super(props);
    this.state={
      quantitySelected:1,
      selectedItem:this.props.selectedItem
    }

  }

  static getDerivedStateFromProps(nextProps,prevState)
  {
    if(prevState.selectedItem.productId !== nextProps.selectedItem.productId)
    {
      return (
        {...prevState,quantitySelected:1,selectedItem:nextProps.selectedItem}
      )
    }
    else
    {
      return prevState;
    }
  
  }


  modifyQuantityEventHandler=(str1)=>{
    if(str1 === "dec")
    {
      if(this.state.quantitySelected >1)
      {
         this.setState((prevState)=>{
            return ({quantitySelected:prevState.quantitySelected-1})
        })
      }
    }
    else
    {
      if(this.state.quantitySelected<this.props.selectedItem.quantity)
      {
        this.setState((prevState)=>{
          return ({quantitySelected:prevState.quantitySelected+1})
        })
      }
    }
  }

  buyEventHandler=()=>{
    //1. send data from child to parent for modifying the quantity
    var cartObj={...this.props.selectedItem,quantitySelected:this.state.quantitySelected};
    //this.props -- companyName,selectedItem,onConfirmation
    // trigger the event onConfirmation
    this.props.onConfirmation(cartObj);
    //2. route to the payments page

  }

  cancelEventHandler=()=>{
    this.props.onCancelConfirmation();
  }
  render() {
    console.log("Inside the render of Add To Cart", this.props);
    // getting some data from the parent
    // this.props -- data coming from the parent
    // props -- immutable; 
    //var item=this.props.selectedItem;// reference
    //item={};// error
    var item ={...this.props.selectedItem};//copy
    return (
      <div>
        <h1>AddToCart</h1>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-4 offset-4 bg-warning text-primary '>

              <img src={item.imgUrl} alt={item.name} className="card-img-top img-responsive" />
              <div className="card-body">
                <h1 className="card-title">{item.name}</h1>
                <p className="card-text">Price : Rs. {item.price}</p>
                <p className="card-text">Quantity : {item.quantity}</p>
                <input type="button" value="-" className='btn btn-success m-2'
                  disabled={this.state.quantitySelected <=1}
                  onClick={this.modifyQuantityEventHandler.bind(this,"dec")}
                />
                <span>{this.state.quantitySelected}</span>
                <input type="button" value="+" className='btn btn-success m-2'
                disabled={this.state.quantitySelected >=item.quantity}
                 onClick={this.modifyQuantityEventHandler.bind(this,"inc")}
                />
                <br/>
                <input type="button" value="Buy" className='btn btn-success m-2'
                  onClick={this.buyEventHandler}
                />
                <input type="button" value="Cancel" className='btn btn-danger m-2'
                  onClick={this.cancelEventHandler}
                />
              </div>
            </div>

          </div>

        </div>

      </div>
    )
  }
}

/*
Props of a component
-- data coming from the parent
-- immutable data

State
-- local mutable data of the componnet
*/
