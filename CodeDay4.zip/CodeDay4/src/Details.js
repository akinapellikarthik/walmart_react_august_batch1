import React from 'react'
import {useParams,useLocation} from "react-router-dom";

function Details() {
   // const obj=useParams();
    //const userId=obj.userId;

    const {userId}=useParams();
    const location=useLocation();
    console.log(location);
    const userDetails=location.state.userDetails;
  return (
    <div>
        <h1>Details Component</h1>
        <h1>User Id:{userId}</h1>
        <p>{JSON.stringify(userDetails)}</p>
    </div>
  )
}

export default Details