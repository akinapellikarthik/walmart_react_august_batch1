import React, { Component } from 'react'
import {useNavigate} from "react-router-dom"
export default function Custome(props) {
  
    var item=props.item;
    const navigate=useNavigate();
    const detailsEventHandler=(userDetails)=>{
        navigate("/details/"+userDetails.id,{state:{userDetails:userDetails}});
    }
    return (
      <React.Fragment>
        <tr>
                <td>{item.id}</td>
                <td>{item.name}</td>
                <td>{item.email}</td>
                <td>
                  <input type="button" value="Details" className='btn btn-primary'
                  onClick={()=>{
                    detailsEventHandler(item);
                  }}/>
                </td>
            </tr>
      </React.Fragment>
    )
  }


